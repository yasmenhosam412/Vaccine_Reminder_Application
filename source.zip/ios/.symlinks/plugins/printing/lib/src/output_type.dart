enum OutputType {
  generic,
  photo,
  grayscale,
  photoGrayscale,
}
