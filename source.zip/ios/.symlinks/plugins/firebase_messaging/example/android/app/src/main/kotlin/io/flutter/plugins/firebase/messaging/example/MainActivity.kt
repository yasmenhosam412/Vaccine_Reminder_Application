package io.flutter.plugins.firebase.messaging.example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
